const anime = [
  {title:"Demo Anime One", year:2026, langs:["Hindi","English"], image:"https://placehold.co/600x850/171a23/ffffff?text=Anime+1"},
  {title:"Demo Anime Two", year:2026, langs:["English"], image:"https://placehold.co/600x850/171a23/ffffff?text=Anime+2"},
  {title:"Demo Anime Three", year:2025, langs:["Hindi"], image:"https://placehold.co/600x850/171a23/ffffff?text=Anime+3"},
  {title:"Demo Anime Four", year:2025, langs:["Hindi","English"], image:"https://placehold.co/600x850/171a23/ffffff?text=Anime+4"}
];

let selectedLang = "all";
const grid = document.querySelector("#animeGrid");
const empty = document.querySelector("#empty");
const input = document.querySelector("#searchInput");

function render(){
  const q = input.value.trim().toLowerCase();
  const list = anime.filter(a =>
    a.title.toLowerCase().includes(q) &&
    (selectedLang === "all" || a.langs.includes(selectedLang))
  );
  grid.innerHTML = list.map(a => `
    <article class="card">
      <div class="poster" style="background-image:url('${a.image}')"></div>
      <div class="info">
        <p class="title">${a.title}</p>
        <div class="meta">${a.year}</div>
        <div class="tags">${a.langs.map(x=>`<span class="tag">${x} Dub</span>`).join("")}</div>
      </div>
    </article>`).join("");
  empty.classList.toggle("hidden", list.length !== 0);
}
document.querySelectorAll(".filter").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    selectedLang = btn.dataset.lang;
    render();
  });
});
input.addEventListener("input", render);
document.querySelector("#searchBtn").addEventListener("click", render);
render();
