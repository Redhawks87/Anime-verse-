# AnimeVerse Starter Website

Files:
- index.html — main page
- style.css — responsive design + Google Font
- script.js — anime catalogue, search and Hindi/English filters

How to run:
1. Extract the ZIP.
2. Open index.html in a browser.
3. Replace the demo anime entries in script.js with anime you are legally allowed to list/stream.
4. For actual video playback, add your own licensed/public-domain/creator-authorized video hosting and player.

Important:
This starter does not include pirated anime, copyrighted video files, or unauthorized streaming links.
